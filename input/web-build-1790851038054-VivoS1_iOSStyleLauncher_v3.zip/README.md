# Vivo S1 Vivo S1 iOS Launcher v2

Versi 2 dengan tampilan lebih dekat ke gaya iPhone:
- Grid 4 kolom x 5 baris
- Ikon lebih besar
- Dock transparan rounded
- Indikator halaman
- Swipe kiri/kanan untuk halaman
- Swipe ke atas membuka App Library
- Jam dan tanggal
- Launcher default Android

Build:
1. Buka folder di Android Studio.
2. Sync Gradle.
3. Build > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk

Untuk vivo S1, instal APK lalu pilih aplikasi ini sebagai Home/Launcher default.
